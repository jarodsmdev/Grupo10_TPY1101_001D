-- ============================================
-- SCRIPT: Crear administrador manualmente
-- ============================================
-- USO:
--   1. Reemplaza 'correo@admin.com' por el email deseado.
--   2. Genera un hash BCrypt para la contraseña deseada en:
--        https://www.bcrypt-generator.com/  (cost 10)
--   3. Reemplaza '$2a$10$...' por el hash generado.
--   4. Ejecuta contra la base de datos authdb.
--
--   Ejemplo de generación de hash con Spring Boot:
--     import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
--     System.out.println(new BCryptPasswordEncoder(10).encode("tu_contraseña"));
--
-- ============================================

INSERT INTO users (rut, dv, name, last_name, email, password, role, is_active, recovery_attempts, created_at, modified_at)
VALUES (
    '11111111',                          -- RUT del administrador
    '1',                                 -- DV del RUT
    'USER ADMIN',                        -- Nombre
    'ROOT',                              -- Apellido
    'correo@admin.com',                  -- << CAMBIAR: email del administrador
    '$2a$10$Z7V4Xk8Xq5f9p2sS1hRuuO6iA3QxYzLmNvBwKcDeFgHjKlMnOpQrStUvWxYz', -- << CAMBIAR: hash BCrypt
    'USER_ADMIN',                        -- Rol de administrador
    1,                                   -- is_active = true
    0,                                   -- recovery_attempts = 0
    NOW(),                               -- created_at
    NOW()                                -- modified_at
);
