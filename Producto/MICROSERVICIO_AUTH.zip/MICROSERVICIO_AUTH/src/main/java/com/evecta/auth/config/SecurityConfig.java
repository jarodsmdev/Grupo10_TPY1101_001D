package com.evecta.auth.config;

import com.evecta.auth.security.JwtAuthenticationFilter;
import lombok.RequiredArgsConstructor;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.security.config.annotation.method.configuration.EnableMethodSecurity;
import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.security.config.annotation.web.configuration.EnableWebSecurity;
import org.springframework.security.config.annotation.web.configurers.AbstractHttpConfigurer;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.security.web.SecurityFilterChain;
import org.springframework.security.web.authentication.UsernamePasswordAuthenticationFilter;

import org.springframework.http.HttpMethod;

@Configuration
@EnableWebSecurity
@EnableMethodSecurity
@RequiredArgsConstructor
public class SecurityConfig {

    private final JwtAuthenticationFilter jwtFilter;

    @Bean
    public SecurityFilterChain securityFilterChain(HttpSecurity http) throws Exception {
        http
                //.cors(Customizer.withDefaults())
                .csrf(AbstractHttpConfigurer::disable)
                .authorizeHttpRequests(auth -> auth
                        // Mapea el JSON/YAML base autogenerado por SpringDoc
                        .requestMatchers("/v3/api-docs").permitAll()
                        .requestMatchers("/v3/api-docs/**").permitAll()
                        // Mapea la interfaz gráfica en caso de que desees consultarla localmente
                        .requestMatchers("/swagger-ui.html").permitAll()
                        .requestMatchers("/swagger-ui/**").permitAll()
                        .requestMatchers(HttpMethod.OPTIONS, "/**").permitAll()
                        .requestMatchers(HttpMethod.POST, "/auth/api/v1/login").permitAll()
                        .requestMatchers(HttpMethod.POST, "/auth/api/v1/refresh").permitAll()
                        .requestMatchers(HttpMethod.POST, "/auth/api/v1/recovery/**").permitAll()
                        // Solo los ADMIN pueden crear, borrar o cambiar roles
                        .requestMatchers(HttpMethod.POST, "/auth/api/v1/users").hasAuthority("USER_ADMIN")
                        .requestMatchers(HttpMethod.DELETE, "/auth/api/v1/users").hasAuthority("USER_ADMIN")
                        .requestMatchers(HttpMethod.PATCH, "/auth/api/v1/users/*/role").hasAuthority("USER_ADMIN")
                        .requestMatchers(HttpMethod.PATCH, "/auth/api/v1/users/*/activate").hasAuthority("USER_ADMIN")
                        // Solo ADMIN pueden gestionar tokens
                        .requestMatchers(HttpMethod.GET, "/auth/api/v1/tokens/**").hasAuthority("USER_ADMIN")
                        .requestMatchers(HttpMethod.PATCH, "/auth/api/v1/tokens/**").hasAuthority("USER_ADMIN")
                        // Cualquier usuario autenticado puede ver la lista
                        .anyRequest().authenticated())
                .httpBasic(AbstractHttpConfigurer::disable)
                .formLogin(AbstractHttpConfigurer::disable)
                .addFilterBefore(jwtFilter, UsernamePasswordAuthenticationFilter.class);
        return http.build();
    }

    // @Bean
    // public CorsConfigurationSource corsConfigurationSource() {
    //     CorsConfiguration configuration = new CorsConfiguration();
    //     // Allow Vite frontend
    //     configuration.setAllowedOrigins(Arrays.asList(
    //             "https://sifacore.netlify.app",
    //             "http://localhost:5173",
    //             "http://localhost:3000"));
    //     //configuration.setAllowCredentials(true); // Permitir cookies (si es necesario)
    //     configuration.setAllowedMethods(Arrays.asList("GET", "POST", "PUT", "DELETE", "PATCH", "OPTIONS"));
    //     // configuration.setAllowedHeaders(Arrays.asList("Authorization",
    //     // "Content-Type"));
    //     configuration.setAllowedHeaders(Arrays.asList("*")); // Permitir todos los headers (incluyendo Authorization)
    //     UrlBasedCorsConfigurationSource source = new UrlBasedCorsConfigurationSource();
    //     source.registerCorsConfiguration("/**", configuration);
    //     return source;
    // }

    @Bean
    public BCryptPasswordEncoder passwordEncoder() {
        return new BCryptPasswordEncoder();
    }
}